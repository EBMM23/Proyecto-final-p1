//Tarea #4, Realizada por: Roniell Pérez | 2021-0032

package FabricaDialog;

//Interfaz para utilizar patrón de diseño fabrica
public interface IDialog {
    public void mostrarDialog();
    public void setTitulo(String titulo);
}
